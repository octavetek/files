/* BranchARM.h */

#ifndef __BRANCH_ARM_H
#define __BRANCH_ARM_H

#include "BranchTypes.h"

UInt32 ARM_Convert(Byte *data, UInt32 size, UInt32 nowPos, int encoding);

#endif

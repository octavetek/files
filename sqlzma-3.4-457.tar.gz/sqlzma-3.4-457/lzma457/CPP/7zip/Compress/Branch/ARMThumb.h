// ARMThumb.h

#ifndef __ARMTHUMB_H
#define __ARMTHUMB_H

#include "BranchCoder.h"

MyClassA(BC_ARMThumb, 0x07, 1)

#endif

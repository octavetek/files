// CompressionMethod.cpp

#include "StdAfx.h"

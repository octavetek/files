// Windows/MemoryLock.h

#ifndef __WINDOWS_MEMORYLOCK_H
#define __WINDOWS_MEMORYLOCK_H

namespace NWindows {
namespace NSecurity {

bool EnableLockMemoryPrivilege(bool enable = true);

}}

#endif 
